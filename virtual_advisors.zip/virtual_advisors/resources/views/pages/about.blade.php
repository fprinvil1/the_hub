@extends('layouts.app')

@section('content')
    <h1>{{$title}}</h1>
    This is the about page
@endsection