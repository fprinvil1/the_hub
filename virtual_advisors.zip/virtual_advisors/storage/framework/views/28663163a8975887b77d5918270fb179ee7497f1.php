<?php echo e($slot); ?>

<?php /**PATH /var/app/current/virtual_advisors/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>