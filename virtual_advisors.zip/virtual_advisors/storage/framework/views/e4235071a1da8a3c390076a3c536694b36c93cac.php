<?php $__env->startSection('content'); ?>
    <h1><?php echo e($title); ?></h1>
    This is the about page
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\virtual_advisors\resources\views/pages/about.blade.php ENDPATH**/ ?>